// Run: node --test test/fees.test.js   (no dependencies)
const test = require('node:test');
const assert = require('node:assert');
const {
  tripTotalCents,
  splitTrip,
  netToHooptyCents,
  hostNetCents,
  actualHostNetCents,
  feeShortfallCents,
  estimateProcessingFeeCents,
} = require('../lib/fees');

test('trip total is daily price x days', () => {
  assert.equal(tripTotalCents(5000, 3), 15000); // $50/day x 3 = $150
  assert.equal(tripTotalCents(5000, 1), 5000);
});

test('days clamp to the site rule: min 1, max 90 (Kris, Nov 18, 2026)', () => {
  assert.equal(tripTotalCents(5000, 0), 5000);
  assert.equal(tripTotalCents(5000, 90), 450000); // $50/day x 90 = $4,500
  assert.equal(tripTotalCents(5000, 99), 450000); // clamped to 90, not 99
});

test('Balanced (default): host 80% gross, Hoopty 20% full cut', () => {
  const s = splitTrip(15000, 'balanced');
  assert.equal(s.hostGrossCents, 12000);
  assert.equal(s.hostAmountCents, 12000); // alias = gross
  assert.equal(s.hooptyFeeCents, 3000);
  assert.equal(s.hostGrossCents + s.hooptyFeeCents, 15000);
});

test('Starter: host 70%, Hoopty 30%', () => {
  const s = splitTrip(15000, 'starter');
  assert.equal(s.hostGrossCents, 10500);
  assert.equal(s.hooptyFeeCents, 4500);
});

test('Top Earner: host 90%, Hoopty 10%', () => {
  const s = splitTrip(15000, 'top_earner');
  assert.equal(s.hostGrossCents, 13500);
  assert.equal(s.hooptyFeeCents, 1500);
});

test('unknown plan falls back to Balanced, never crashes the split', () => {
  const s = splitTrip(10000, 'mystery-plan');
  assert.equal(s.plan, 'balanced');
  assert.equal(s.hostGrossCents, 8000);
});

test('split always adds up exactly, even with odd cents', () => {
  for (const total of [1, 99, 101, 3333, 9999, 15000]) {
    for (const plan of ['starter', 'balanced', 'top_earner']) {
      const s = splitTrip(total, plan);
      assert.equal(s.hostGrossCents + s.hooptyFeeCents, total);
    }
  }
});

// Kris's decision, Nov 17: HOST pays the Stripe fee out of their share.
// Hoopty keeps its FULL cut. $150 trip (3 days x $50):
//   Balanced:   host $120.00 gross - $4.65 fee = $115.35 net, Hoopty $30.00
//   Starter:    host $105.00 gross - $4.65 fee = $100.35 net, Hoopty $45.00
//   Top Earner: host $135.00 gross - $4.65 fee = $130.35 net, Hoopty $15.00
test('host pays the Stripe fee — $150 trip table, all three plans', () => {
  assert.equal(estimateProcessingFeeCents(15000), 465); // 2.9% + 30c

  const balanced = splitTrip(15000, 'balanced');
  assert.equal(balanced.stripeFeeEstimateCents, 465);
  assert.equal(balanced.hostNetCents, 11535);
  assert.equal(hostNetCents(15000, 'balanced'), 11535);
  assert.equal(netToHooptyCents(15000, 'balanced'), 3000); // full cut, NOT 2535

  const starter = splitTrip(15000, 'starter');
  assert.equal(starter.hostNetCents, 10035);
  assert.equal(netToHooptyCents(15000, 'starter'), 4500);

  const top = splitTrip(15000, 'top_earner');
  assert.equal(top.hostNetCents, 13035);
  assert.equal(netToHooptyCents(15000, 'top_earner'), 1500);
});

test('estimated split always reconciles: host net + fee + Hoopty = total', () => {
  for (const total of [5000, 10000, 15000, 3333, 9999]) {
    for (const plan of ['starter', 'balanced', 'top_earner']) {
      const s = splitTrip(total, plan);
      assert.equal(s.hostNetCents + s.stripeFeeEstimateCents + s.hooptyFeeCents, total);
    }
  }
});

test('final host net uses the ACTUAL fee from the charge, not the estimate', () => {
  // Same $150 Balanced trip, but the card actually cost $5.55 (e.g. a
  // higher-fee payment method): host net drops to $114.45, Hoopty still $30.
  assert.equal(actualHostNetCents(12000, 555), 11445);
  // And if the actual fee matches the estimate, net matches the estimate.
  assert.equal(actualHostNetCents(12000, 465), 11535);
  assert.equal(actualHostNetCents(10500, 465), 10035);
  assert.equal(actualHostNetCents(13500, 465), 13035);
});

test('host net clamps at $0 and the shortfall is recorded, never hidden', () => {
  // Absurd case only: $1.00 trip, host gross $0.80, actual fee $1.00.
  assert.equal(actualHostNetCents(80, 100), 0);
  assert.equal(feeShortfallCents(80, 100), 20);
  assert.equal(feeShortfallCents(12000, 465), 0);
});

test('old math is gone: Hoopty does NOT net $25.35 on a $150 Balanced trip', () => {
  assert.notEqual(netToHooptyCents(15000, 'balanced'), 2535);
  assert.equal(netToHooptyCents(15000, 'balanced'), 3000);
});
