// Pure availability tests — run: node --test test/availability.test.js
// No server, no Stripe, no network.
const test = require('node:test');
const assert = require('node:assert');
const {
  datesOverlap,
  findOverlappingBooking,
  blockedDateInRange,
  validateTripDates,
  isValidDateString,
} = require('../lib/availability');

const camry = { id: 'test-camry-001', minTripDays: 1, maxTripDays: 30, blockedDates: [] };

function paidBooking(startDate, endDate, overrides = {}) {
  return {
    id: 'bk_x',
    listingId: 'test-camry-001',
    status: 'paid',
    startDate,
    endDate,
    ...overrides,
  };
}

test('datesOverlap: partial overlap both ways', () => {
  assert.equal(datesOverlap('2026-11-24', '2026-11-27', '2026-11-25', '2026-11-28'), true);
  assert.equal(datesOverlap('2026-11-25', '2026-11-28', '2026-11-24', '2026-11-27'), true);
});

test('datesOverlap: exact same dates overlap', () => {
  assert.equal(datesOverlap('2026-11-24', '2026-11-27', '2026-11-24', '2026-11-27'), true);
});

test('datesOverlap: one trip fully inside another overlaps', () => {
  assert.equal(datesOverlap('2026-11-24', '2026-11-30', '2026-11-25', '2026-11-26'), true);
});

test('datesOverlap: back-to-back (end == next start) does NOT overlap', () => {
  assert.equal(datesOverlap('2026-11-24', '2026-11-27', '2026-11-27', '2026-11-30'), false);
  assert.equal(datesOverlap('2026-11-27', '2026-11-30', '2026-11-24', '2026-11-27'), false);
});

test('datesOverlap: gap between trips does NOT overlap', () => {
  assert.equal(datesOverlap('2026-11-24', '2026-11-27', '2026-11-28', '2026-11-30'), false);
  assert.equal(datesOverlap('2026-11-28', '2026-11-30', '2026-11-24', '2026-11-27'), false);
});

test('findOverlappingBooking: paid booking blocks, awaiting_payment does not', () => {
  const bookings = [paidBooking('2026-11-24', '2026-11-27')];
  assert.ok(findOverlappingBooking(bookings, 'test-camry-001', '2026-11-25', '2026-11-26'));
  assert.equal(findOverlappingBooking(bookings, 'test-camry-001', '2026-11-27', '2026-11-30'), null);
  const unpaid = [paidBooking('2026-11-24', '2026-11-27', { status: 'awaiting_payment' })];
  assert.equal(findOverlappingBooking(unpaid, 'test-camry-001', '2026-11-25', '2026-11-26'), null);
});

test('findOverlappingBooking: other listings never block', () => {
  const bookings = [paidBooking('2026-11-24', '2026-11-27', { listingId: 'car_other' })];
  assert.equal(findOverlappingBooking(bookings, 'test-camry-001', '2026-11-25', '2026-11-26'), null);
});

test('blockedDateInRange: half-open — return day is free', () => {
  const listing = { ...camry, blockedDates: ['2026-11-26'] };
  assert.equal(blockedDateInRange(listing, '2026-11-25', '2026-11-28'), true);
  assert.equal(blockedDateInRange(listing, '2026-11-24', '2026-11-26'), false); // returns on the 26th
  assert.equal(blockedDateInRange(listing, '2026-11-26', '2026-11-27'), true);
  assert.equal(blockedDateInRange({ ...camry, blockedDates: [] }, '2026-11-25', '2026-11-28'), false);
});

test('validateTripDates: overlapping paid trip → dates_unavailable', () => {
  const r = validateTripDates(camry, [paidBooking('2026-11-24', '2026-11-27')], '2026-11-26', '2026-11-29');
  assert.equal(r.ok, false);
  assert.equal(r.error, 'dates_unavailable');
  assert.match(r.message, /already booked/);
});

test('validateTripDates: back-to-back and clear dates pass', () => {
  const bookings = [paidBooking('2026-11-24', '2026-11-27')];
  assert.deepEqual(validateTripDates(camry, bookings, '2026-11-27', '2026-11-30'), { ok: true, days: 3 });
  assert.deepEqual(validateTripDates(camry, bookings, '2026-11-28', '2026-11-30'), { ok: true, days: 2 });
  assert.deepEqual(validateTripDates(camry, [], '2026-11-24', '2026-11-27'), { ok: true, days: 3 });
});

test('validateTripDates: blocked date → dates_blocked; min/max trip enforced', () => {
  const blocked = { ...camry, blockedDates: ['2026-11-26'] };
  const b = validateTripDates(blocked, [], '2026-11-25', '2026-11-28');
  assert.equal(b.ok, false);
  assert.equal(b.error, 'dates_blocked');

  const min3 = { ...camry, minTripDays: 3, maxTripDays: 7 };
  assert.equal(validateTripDates(min3, [], '2026-11-24', '2026-11-25').error, 'trip_too_short');
  assert.equal(validateTripDates(min3, [], '2026-11-24', '2026-12-02').error, 'trip_too_long');
  assert.equal(validateTripDates(min3, [], '2026-11-24', '2026-11-27').ok, true);
});

test('validateTripDates: bad dates and out-of-range trips → invalid_dates', () => {
  assert.equal(validateTripDates(camry, [], '2026-13-40', '2026-11-27').error, 'invalid_dates');
  assert.equal(validateTripDates(camry, [], '2026-11-27', '2026-11-24').error, 'invalid_dates');
  assert.equal(validateTripDates(camry, [], '2026-11-24', '2026-12-25').error, 'invalid_dates');
  assert.equal(isValidDateString('2026-02-30'), false);
  assert.equal(isValidDateString('2026-11-24'), true);
});
