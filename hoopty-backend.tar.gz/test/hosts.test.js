// Pure host auto-link tests — run: node --test test/hosts.test.js
// No server, no Stripe, no network.
const test = require('node:test');
const assert = require('node:assert');
const { linkListingsForHost, syncListingsFromHosts, normaliseEmail } = require('../lib/hosts');

function listing(overrides = {}) {
  return {
    id: 'test-camry-001',
    hostEmail: 'host-test@example.com',
    hostStripeAccountId: null,
    ...overrides,
  };
}

test('linkListingsForHost links only that host’s unlinked listings', () => {
  const listings = [
    listing(),
    listing({ id: 'car_other', hostEmail: 'other@example.com' }),
    listing({ id: 'car_linked', hostStripeAccountId: 'acct_existing' }),
  ];
  const { listings: out, linkedIds } = linkListingsForHost(listings, 'host-test@example.com', 'acct_new');
  assert.deepEqual(linkedIds, ['test-camry-001']);
  assert.equal(out[0].hostStripeAccountId, 'acct_new');
  assert.equal(out[1].hostStripeAccountId, null);
  assert.equal(out[2].hostStripeAccountId, 'acct_existing'); // never overwritten
  assert.equal(listings[0].hostStripeAccountId, null); // inputs untouched
});

test('linkListingsForHost matches email case-insensitively', () => {
  const { linkedIds } = linkListingsForHost([listing()], 'HOST-TEST@EXAMPLE.COM', 'acct_new');
  assert.deepEqual(linkedIds, ['test-camry-001']);
  assert.equal(normaliseEmail('  Host-Test@Example.com '), 'host-test@example.com');
});

test('linkListingsForHost with no account id links nothing', () => {
  const { linkedIds, listings: out } = linkListingsForHost([listing()], 'host-test@example.com', null);
  assert.deepEqual(linkedIds, []);
  assert.equal(out[0].hostStripeAccountId, null);
});

test('syncListingsFromHosts links completed hosts only', () => {
  const listings = [
    listing(),
    listing({ id: 'car_pending', hostEmail: 'pending@example.com' }),
    listing({ id: 'car_no_record', hostEmail: 'ghost@example.com' }),
  ];
  const hosts = {
    'host-test@example.com': { stripeAccountId: 'acct_camry', onboardingComplete: true },
    'pending@example.com': { stripeAccountId: 'acct_pending', onboardingComplete: false },
  };
  const { listings: out, linkedIds } = syncListingsFromHosts(listings, hosts);
  assert.deepEqual(linkedIds, ['test-camry-001']);
  assert.equal(out[0].hostStripeAccountId, 'acct_camry');
  assert.equal(out[1].hostStripeAccountId, null); // onboarding not complete
  assert.equal(out[2].hostStripeAccountId, null); // no host record at all
});

test('syncListingsFromHosts tolerates a missing/empty hosts store', () => {
  const { linkedIds } = syncListingsFromHosts([listing()], null);
  assert.deepEqual(linkedIds, []);
  const { linkedIds: none } = syncListingsFromHosts([listing()], {});
  assert.deepEqual(none, []);
});
