// Harness test for POST /api/listings — run: node --test test/listings.test.js
// (or plain `node --test` in backend/ to run the fee tests too).
//
// Spins up a COPY of the backend in a temp dir, so the draft data files
// are never touched. The fake Stripe key is never used for a real call:
// the listing endpoint needs no Stripe at all, and the checkout-gate
// test stops at the payouts check (409) before any Stripe call happens.
// No network, no real money, no accounts created.
const test = require('node:test');
const assert = require('node:assert');
const { spawn } = require('node:child_process');
const fs = require('node:fs');
const os = require('node:os');
const path = require('node:path');

const PORT = 34567;
const BASE = `http://127.0.0.1:${PORT}`;
const ROOT = path.join(__dirname, '..');

let dir;
let child;
let createdId;

async function waitForHealth(tries = 40) {
  for (let i = 0; i < tries; i++) {
    try {
      const r = await fetch(`${BASE}/api/health`);
      if (r.ok) return;
    } catch { /* not up yet */ }
    await new Promise((r) => setTimeout(r, 200));
  }
  throw new Error('backend did not come up');
}

async function post(pathname, body) {
  const r = await fetch(`${BASE}${pathname}`, {
    method: 'POST',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body),
  });
  const data = await r.json().catch(() => ({}));
  return { status: r.status, data };
}

async function del(pathname, body) {
  const r = await fetch(`${BASE}${pathname}`, {
    method: 'DELETE',
    headers: { 'content-type': 'application/json' },
    body: JSON.stringify(body || {}),
  });
  const data = await r.json().catch(() => ({}));
  return { status: r.status, data };
}

async function listCount() {
  return (await (await fetch(`${BASE}/api/listings`)).json()).listings.length;
}

async function listIds() {
  return (await (await fetch(`${BASE}/api/listings`)).json()).listings.map((l) => l.id);
}

// The server re-reads bookings.json on every request, so a test can seed
// bookings mid-run by rewriting the file.
function seedBookings(bookings) {
  fs.writeFileSync(path.join(dir, 'data', 'bookings.json'), JSON.stringify(bookings, null, 2));
}

function fakeBooking(overrides = {}) {
  return {
    id: `bk_test_${Math.random().toString(36).slice(2, 8)}`,
    listingId: createdId,
    renterEmail: 'verified-renter@example.com',
    renterName: 'Verified Renter',
    startDate: '2026-11-24',
    endDate: '2026-11-27',
    days: 3,
    totalCents: 15000,
    status: 'paid',
    createdAt: new Date().toISOString(),
    ...overrides,
  };
}

test.before(async () => {
  dir = fs.mkdtempSync(path.join(os.tmpdir(), 'hoopty-listings-test-'));
  fs.cpSync(path.join(ROOT, 'server.js'), path.join(dir, 'server.js'));
  fs.cpSync(path.join(ROOT, 'lib'), path.join(dir, 'lib'), { recursive: true });
  fs.mkdirSync(path.join(dir, 'data'), { recursive: true });
  // Seed: the test Camry only, plus a verified renter for the checkout
  // gate test. hosts.json seeds the Camry's host as ALREADY onboarded
  // (charges+payouts enabled, test account id) so the auto-link path is
  // exercised: GET /api/listings must link the Camry to acct_test_camry
  // without any hand-edit of listings.json. A fresh host (not in this
  // store) is still payouts-not-ready — see the checkout gate test.
  const camry = JSON.parse(fs.readFileSync(path.join(ROOT, 'data', 'listings.json'), 'utf8'));
  fs.writeFileSync(path.join(dir, 'data', 'listings.json'), JSON.stringify(camry, null, 2));
  fs.writeFileSync(path.join(dir, 'data', 'bookings.json'), '[]');
  fs.writeFileSync(path.join(dir, 'data', 'renters.json'), JSON.stringify({
    'verified-renter@example.com': {
      email: 'verified-renter@example.com',
      identityStatus: 'verified',
      verifiedAt: new Date().toISOString(),
    },
  }, null, 2));
  fs.writeFileSync(path.join(dir, 'data', 'hosts.json'), JSON.stringify({
    'host-test@example.com': {
      email: 'host-test@example.com',
      hostName: 'Test Host',
      stripeAccountId: 'acct_test_camry',
      onboardingComplete: true,
    },
  }, null, 2));
  fs.symlinkSync(path.join(ROOT, 'node_modules'), path.join(dir, 'node_modules'), 'dir');
  child = spawn('node', ['server.js'], {
    cwd: dir,
    env: {
      ...process.env,
      PORT: String(PORT),
      STRIPE_SECRET_KEY: 'sk_test_fake_for_harness_only',
      FRONTEND_URL: 'https://hoopty.rent',
    },
    stdio: 'ignore',
  });
  await waitForHealth();
});

test.after(async () => {
  if (child) child.kill('SIGTERM');
  if (dir) fs.rmSync(dir, { recursive: true, force: true });
});

function validCar(overrides = {}) {
  return {
    hostEmail: 'new-host@example.com',
    hostName: 'New Host',
    year: 2021,
    make: 'Honda',
    model: 'Civic',
    location: 'Boston, MA',
    pricePerDay: 60,
    seats: 5,
    transmission: 'Automatic',
    fuelType: 'Gas',
    bodyType: 'Sedan',
    features: ['Bluetooth'],
    description: 'Clean Civic',
    planKeep: 80,
    minTripDays: 1,
    maxTripDays: 30,
    blockedDates: [],
    ...overrides,
  };
}

test('valid create stores the listing with payouts not ready', async () => {
  const { status, data } = await post('/api/listings', validCar());
  assert.equal(status, 201);
  assert.equal(data.ok, true);
  const l = data.listing;
  assert.ok(l.id.startsWith('car_'));
  assert.equal(l.hostPlan, 'balanced');
  assert.equal(l.pricePerDayCents, 6000); // $60/day in cents
  assert.equal(l.payoutsReady, false);
  assert.equal('hostStripeAccountId' in l, false); // never leaked
  assert.equal(l.testListing, false);
  createdId = l.id;

  // Stored: the list now has the Camry + the new car.
  const list = await (await fetch(`${BASE}/api/listings`)).json();
  assert.equal(list.listings.length, 2);
  const mine = list.listings.find((x) => x.id === createdId);
  assert.ok(mine);
  assert.equal('hostStripeAccountId' in mine, false);

  // Single-listing fetch agrees.
  const one = await (await fetch(`${BASE}/api/listings/${createdId}`)).json();
  assert.equal(one.listing.payoutsReady, false);
  assert.equal(one.listing.make, 'Honda');
});

test('planKeep 90 maps to Top Earner; cents price accepted', async () => {
  const { status, data } = await post('/api/listings', validCar({
    hostEmail: 'top-host@example.com',
    pricePerDay: undefined,
    pricePerDayCents: 7500,
    planKeep: 90,
  }));
  assert.equal(status, 201);
  assert.equal(data.listing.hostPlan, 'top_earner');
  assert.equal(data.listing.pricePerDayCents, 7500);
});

test('missing required field → 400 and nothing saved', async () => {
  const before = (await (await fetch(`${BASE}/api/listings`)).json()).listings.length;
  const { status, data } = await post('/api/listings', validCar({ make: '' }));
  assert.equal(status, 400);
  assert.equal(data.ok, false);
  assert.match(data.error, /Make is required/);
  const after = (await (await fetch(`${BASE}/api/listings`)).json()).listings.length;
  assert.equal(after, before);
});

test('bad plan → 400', async () => {
  const badName = await post('/api/listings', validCar({ planKeep: undefined, plan: 'premium' }));
  assert.equal(badName.status, 400);
  assert.match(badName.data.error, /Plan must be/);
  const badKeep = await post('/api/listings', validCar({ planKeep: 55 }));
  assert.equal(badKeep.status, 400);
  assert.match(badKeep.data.error, /Plan must be/);
});

test('checkout on the new un-onboarded listing refuses with host_payouts_not_ready', async () => {
  const { status, data } = await post('/api/checkout', {
    listingId: createdId,
    startDate: '2026-11-18',
    endDate: '2026-11-21',
    renterEmail: 'verified-renter@example.com',
    renterName: 'Verified Renter',
  });
  assert.equal(status, 409);
  assert.equal(data.error, 'host_payouts_not_ready');
});

// ---------------------------------------------------------------------------
// Issue 1 — testListing flag
// ---------------------------------------------------------------------------
test('description marked TEST LISTING ONLY is NOT flagged by the backend alone', async () => {
  // The flag is explicit in the request body (the shim sets it from the
  // description). A bare description must not flip it server-side.
  const { status, data } = await post('/api/listings', validCar({
    hostEmail: 'test-flag@example.com',
    description: 'TEST LISTING ONLY — Civic for verifying the flow. Not a real car.',
  }));
  assert.equal(status, 201);
  assert.equal(data.listing.testListing, false);
});

test('explicit testListing:true in the request is honoured', async () => {
  const { status, data } = await post('/api/listings', validCar({
    hostEmail: 'test-flag@example.com',
    description: 'TEST LISTING ONLY — Civic for verifying the flow. Not a real car.',
    testListing: true,
  }));
  assert.equal(status, 201);
  assert.equal(data.listing.testListing, true);
  const one = await (await fetch(`${BASE}/api/listings/${data.listing.id}`)).json();
  assert.equal(one.listing.testListing, true);
});

test('a normal description stays testListing:false', async () => {
  const { status, data } = await post('/api/listings', validCar({
    hostEmail: 'test-flag@example.com',
    description: 'Clean Civic, great on gas.',
  }));
  assert.equal(status, 201);
  assert.equal(data.listing.testListing, false);
});

// ---------------------------------------------------------------------------
// Issue 2 — DELETE /api/listings/:id
// ---------------------------------------------------------------------------
test('delete your own listing works and removes it from the file', async () => {
  const { data } = await post('/api/listings', validCar({
    hostEmail: 'delete-me@example.com',
    make: 'Ford',
    model: 'Focus',
  }));
  const id = data.listing.id;
  assert.ok((await listIds()).includes(id));
  const before = await listCount();
  const res = await del(`/api/listings/${id}`, { hostEmail: 'delete-me@example.com' });
  assert.equal(res.status, 200);
  assert.equal(res.data.ok, true);
  assert.equal(res.data.deletedId, id);
  assert.equal(await listCount(), before - 1);
  assert.ok(!(await listIds()).includes(id));
  const gone = await fetch(`${BASE}/api/listings/${id}`);
  assert.equal(gone.status, 404);
});

test('delete another host’s listing → 403 and nothing deleted', async () => {
  const { data } = await post('/api/listings', validCar({
    hostEmail: 'owner-a@example.com',
    make: 'Kia',
    model: 'Rio',
  }));
  const id = data.listing.id;
  const before = await listCount();
  const res = await del(`/api/listings/${id}`, { hostEmail: 'not-the-owner@example.com' });
  assert.equal(res.status, 403);
  assert.match(res.data.error, /only remove your own/);
  assert.equal(await listCount(), before);
  assert.ok((await listIds()).includes(id));
});

test('delete with a paid upcoming booking → 409 and nothing deleted', async () => {
  seedBookings([fakeBooking({ listingId: createdId, status: 'paid', startDate: '2026-11-24', endDate: '2026-11-27' })]);
  const before = await listCount();
  const res = await del(`/api/listings/${createdId}`, { hostEmail: 'new-host@example.com' });
  assert.equal(res.status, 409);
  assert.match(res.data.error, /live booking/);
  assert.equal(await listCount(), before);
  assert.ok((await listIds()).includes(createdId));
});

test('delete with a paid booking that already ended → allowed', async () => {
  seedBookings([fakeBooking({ listingId: createdId, status: 'paid', startDate: '2026-11-01', endDate: '2026-11-03' })]);
  const before = await listCount();
  const res = await del(`/api/listings/${createdId}`, { hostEmail: 'new-host@example.com' });
  assert.equal(res.status, 200);
  assert.equal(res.data.deletedId, createdId);
  assert.equal(await listCount(), before - 1);
  seedBookings([]);
});

test('delete with an unpaid upcoming booking → 409', async () => {
  const { data } = await post('/api/listings', validCar({
    hostEmail: 'awaiting@example.com',
    make: 'Subaru',
    model: 'Outback',
  }));
  const id = data.listing.id;
  seedBookings([fakeBooking({ listingId: id, status: 'awaiting_payment', startDate: '2026-11-24', endDate: '2026-11-27' })]);
  const res = await del(`/api/listings/${id}`, { hostEmail: 'awaiting@example.com' });
  assert.equal(res.status, 409);
  assert.ok((await listIds()).includes(id));
  seedBookings([]);
});

test('delete a missing listing → 404; delete without an email → 400', async () => {
  const missing = await del('/api/listings/car_does_not_exist', { hostEmail: 'new-host@example.com' });
  assert.equal(missing.status, 404);
  const noEmail = await del(`/api/listings/${createdId}`, {});
  assert.equal(noEmail.status, 400);
  assert.match(noEmail.data.error, /host email is required/);
});

// ---------------------------------------------------------------------------
// Fix 2 — auto-link hosts who onboard after listing (HTTP wiring)
// ---------------------------------------------------------------------------
function storedListings() {
  return JSON.parse(fs.readFileSync(path.join(dir, 'data', 'listings.json'), 'utf8'));
}
function storedBookings() {
  return JSON.parse(fs.readFileSync(path.join(dir, 'data', 'bookings.json'), 'utf8'));
}
async function quote(listingId, startDate, endDate) {
  const r = await fetch(
    `${BASE}/api/quote?listingId=${encodeURIComponent(listingId)}&startDate=${startDate}&endDate=${endDate}`
  );
  return { status: r.status, data: await r.json() };
}

test('auto-link: GET /api/listings links the Camry to its onboarded host', async () => {
  const list = await (await fetch(`${BASE}/api/listings`)).json();
  const camry = list.listings.find((l) => l.id === 'test-camry-001');
  assert.ok(camry, 'seed Camry should be listed');
  assert.equal(camry.payoutsReady, true);
  assert.equal('hostStripeAccountId' in camry, false); // never leaked to the browser
  // The link persisted to the file — no hand-edit was needed.
  const storedCamry = storedListings().find((l) => l.id === 'test-camry-001');
  assert.equal(storedCamry.hostStripeAccountId, 'acct_test_camry');
  const one = await (await fetch(`${BASE}/api/listings/test-camry-001`)).json();
  assert.equal(one.listing.payoutsReady, true);
});

test('auto-link: host with onboardingComplete:false is NOT linked', async () => {
  const { data } = await post('/api/listings', validCar({
    hostEmail: 'pending-host@example.com',
    make: 'Nissan',
    model: 'Sentra',
  }));
  const id = data.listing.id;
  assert.equal(data.listing.payoutsReady, false);
  const hosts = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'hosts.json'), 'utf8'));
  hosts['pending-host@example.com'] = {
    email: 'pending-host@example.com',
    stripeAccountId: 'acct_pending',
    onboardingComplete: false,
  };
  fs.writeFileSync(path.join(dir, 'data', 'hosts.json'), JSON.stringify(hosts, null, 2));
  const one = await (await fetch(`${BASE}/api/listings/${id}`)).json();
  assert.equal(one.listing.payoutsReady, false);
  // Clean up: restore the hosts store so later listings reads never pay
  // for a Stripe re-check on this pending host.
  delete hosts['pending-host@example.com'];
  fs.writeFileSync(path.join(dir, 'data', 'hosts.json'), JSON.stringify(hosts, null, 2));
});

test('auto-link: GET /api/listings with a pending host still answers (Stripe fail-open)', { timeout: 15000 }, async () => {
  // The plural listings endpoint re-checks pending hosts with Stripe.
  // With the harness's fake key Stripe rejects — the endpoint must still
  // answer 200 with the unlinked listing, not hang or 500. (The 3s cap
  // in refreshPendingHostOnboarding bounds this even if Stripe is slow.)
  const { data } = await post('/api/listings', validCar({
    hostEmail: 'pending-host@example.com',
    make: 'Nissan',
    model: 'Sentra',
  }));
  const id = data.listing.id;
  const hosts = JSON.parse(fs.readFileSync(path.join(dir, 'data', 'hosts.json'), 'utf8'));
  hosts['pending-host@example.com'] = {
    email: 'pending-host@example.com',
    stripeAccountId: 'acct_pending',
    onboardingComplete: false,
  };
  fs.writeFileSync(path.join(dir, 'data', 'hosts.json'), JSON.stringify(hosts, null, 2));
  const r = await fetch(`${BASE}/api/listings`);
  assert.equal(r.status, 200);
  const list = await r.json();
  const mine = list.listings.find((l) => l.id === id);
  assert.ok(mine);
  assert.equal(mine.payoutsReady, false);
  delete hosts['pending-host@example.com'];
  fs.writeFileSync(path.join(dir, 'data', 'hosts.json'), JSON.stringify(hosts, null, 2));
});

test('auto-link: POST /api/listings links immediately when the host already onboarded', async () => {
  const { status, data } = await post('/api/listings', validCar({
    hostEmail: 'host-test@example.com',
    make: 'Toyota',
    model: 'Corolla',
  }));
  assert.equal(status, 201);
  assert.equal(data.listing.payoutsReady, true);
});

// ---------------------------------------------------------------------------
// Fix 1 — overlap check at checkout (HTTP wiring)
// ---------------------------------------------------------------------------
test('overlap: checkout on dates overlapping a paid booking → 409, nothing created', async () => {
  seedBookings([fakeBooking({
    listingId: 'test-camry-001',
    status: 'paid',
    startDate: '2026-11-24',
    endDate: '2026-11-27',
  })]);
  const before = storedBookings().length;
  for (const [startDate, endDate] of [['2026-11-25', '2026-11-28'], ['2026-11-26', '2026-11-27']]) {
    const { status, data } = await post('/api/checkout', {
      listingId: 'test-camry-001',
      startDate,
      endDate,
      renterEmail: 'verified-renter@example.com',
      renterName: 'Verified Renter',
    });
    assert.equal(status, 409, `${startDate}–${endDate} must be rejected`);
    assert.equal(data.error, 'dates_unavailable');
    assert.match(data.message, /already booked/);
  }
  // No Checkout Session was created and no booking record was added.
  assert.equal(storedBookings().length, before);
  assert.ok(!storedBookings().some((b) => b.status === 'awaiting_payment'));
});

test('quote: overlapping dates → available:false; back-to-back → available:true', async () => {
  const over = await quote('test-camry-001', '2026-11-25', '2026-11-28');
  assert.equal(over.status, 200);
  assert.equal(over.data.available, false);
  assert.equal(over.data.unavailableError, 'dates_unavailable');
  assert.match(over.data.unavailableReason, /already booked/);
  assert.equal(over.data.totalCents, 15000); // price fields still present
  const back = await quote('test-camry-001', '2026-11-27', '2026-11-30');
  assert.equal(back.status, 200);
  assert.equal(back.data.available, true);
  assert.equal(back.data.unavailableReason, null);
  assert.equal(back.data.unavailableError, null);
});

test('quote: blocked date and min-trip → available:false', async () => {
  const { data } = await post('/api/listings', validCar({
    hostEmail: 'blocked-host@example.com',
    make: 'Mazda',
    model: '3',
    blockedDates: ['2026-11-26'],
    minTripDays: 3,
  }));
  const id = data.listing.id;
  const blocked = await quote(id, '2026-11-25', '2026-11-28');
  assert.equal(blocked.data.available, false);
  assert.equal(blocked.data.unavailableError, 'dates_blocked');
  const short = await quote(id, '2026-11-24', '2026-11-25');
  assert.equal(short.data.available, false);
  assert.equal(short.data.unavailableError, 'trip_too_short');
  const ok = await quote(id, '2026-11-27', '2026-11-30');
  assert.equal(ok.data.available, true);
});

test('overlap: checkout on a blocked date → 409 dates_blocked', async () => {
  // Host is onboarded (host-test), so the payouts gate passes and the
  // availability gate is what refuses — proving the check runs in order.
  const { data } = await post('/api/listings', validCar({
    hostEmail: 'host-test@example.com',
    make: 'Mazda',
    model: '3',
    blockedDates: ['2026-11-26'],
  }));
  const { status, data: out } = await post('/api/checkout', {
    listingId: data.listing.id,
    startDate: '2026-11-25',
    endDate: '2026-11-28',
    renterEmail: 'verified-renter@example.com',
    renterName: 'Verified Renter',
  });
  assert.equal(status, 409);
  assert.equal(out.error, 'dates_blocked');
  seedBookings([]);
});
